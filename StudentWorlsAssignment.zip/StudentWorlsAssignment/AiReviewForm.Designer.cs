﻿namespace StudentWorlsAssignment
{
    partial class AiReviewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AiReviewForm));
            rtbAiReview = new RichTextBox();
            labelStudent = new Label();
            listBoxAiFiles = new ListBox();
            SuspendLayout();
            // 
            // rtbAiReview
            // 
            rtbAiReview.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            rtbAiReview.Location = new Point(3, 129);
            rtbAiReview.MinimumSize = new Size(100, 0);
            rtbAiReview.Name = "rtbAiReview";
            rtbAiReview.Size = new Size(279, 298);
            rtbAiReview.TabIndex = 0;
            rtbAiReview.Text = "";
            // 
            // labelStudent
            // 
            labelStudent.AutoSize = true;
            labelStudent.Location = new Point(12, 9);
            labelStudent.Name = "labelStudent";
            labelStudent.Size = new Size(84, 15);
            labelStudent.TabIndex = 1;
            labelStudent.Text = "ФИО студента";
            // 
            // listBoxAiFiles
            // 
            listBoxAiFiles.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            listBoxAiFiles.FormattingEnabled = true;
            listBoxAiFiles.HorizontalScrollbar = true;
            listBoxAiFiles.Location = new Point(3, 27);
            listBoxAiFiles.MinimumSize = new Size(100, 0);
            listBoxAiFiles.Name = "listBoxAiFiles";
            listBoxAiFiles.Size = new Size(279, 49);
            listBoxAiFiles.TabIndex = 2;
            // 
            // AiReviewForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(383, 450);
            Controls.Add(listBoxAiFiles);
            Controls.Add(labelStudent);
            Controls.Add(rtbAiReview);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AiReviewForm";
            Text = "AiReviewForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox rtbAiReview;
        private Label labelStudent;
        private ListBox listBoxAiFiles;
    }
}